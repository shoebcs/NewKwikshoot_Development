<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Controller;
use App\Controller\AppController;
class UsersController extends AppController
{
    public function initialize()
{
parent::initialize();
$this->loadComponent('Flash'); // Include the FlashComponent
}
  public function index(){
       $this->layout = false;
      
  }
  public function joblisting(){
      
      $this->layout = false;
  }
   public function userlisting(){
       $this->layout = false;
       $this->set('users', $this->Users->find('all'));
       
   }
  public function jobcalculator(){
      $this->layout = false;
  }
  public function translisting(){
      $this->layout = false;
  }
}