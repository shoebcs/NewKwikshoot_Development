<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Controller;
use App\Controller\AppController;
class JobsController extends AppController
{
    public function initialize()
{
parent::initialize();
$this->loadComponent('Flash'); // Include the FlashComponent
}
   public function joblisting(){
      $this->layout = false;
      $this->set('jobs', $this->Jobs->find('all'));
  }
  
}