<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Controller;
use App\Controller\AppController;
class EditorsController extends AppController
{
    public function initialize()
{
parent::initialize();
$this->loadComponent('Flash'); // Include the FlashComponent
}
   public function editorlisting(){
      $this->layout = false;
      $this->set('editors', $this->Editors->find('all'));
  }
  public function edit($id = null)
{
$this->layout = false;
$editor = $this->Editors->get($id);
if ($this->request->is(['post', 'put'])) {
$this->Editors->patchEntity($editor, $this->request->data);
if ($this->Editors->save($editor)) {
$this->Flash->success(__('Your article with id: {0} has been updated.', h($id)));
return $this->redirect(['action' => 'editorlisting']);
}
$this->Flash->error(__('Unable to update your article.'));
}
$this->set('editor', $editor);
}

public function addnew()
{
     $this->layout = false;
 $editor = $this->Editors->newEntity();
if ($this->request->is('post')) {
$editor = $this->Editors->patchEntity($editor, $this->request->data);
if ($this->Editors->save($editor)) {
$this->Flash->success(__('Your article has been saved.'));
return $this->redirect(['action' => 'editorlisting']);
}
$this->Flash->error(__('Unable to add your article.'));
}
$this->set('editor', $editor);
}
  
}